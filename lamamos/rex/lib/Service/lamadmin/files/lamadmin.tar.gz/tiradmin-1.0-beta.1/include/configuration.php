<?php
    $PathToRexConfiguration = "/home/karlito/creation/tiranos/rex/";
?>