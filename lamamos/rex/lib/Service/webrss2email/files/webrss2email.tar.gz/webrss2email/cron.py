#!/usr/bin/python

import sys
import os
from config import *

location = os.path.split(sys.argv[0])[0]

sys.path.append(location + "/" + RSS2EMAIL_PATH)
import rss2email
from rss2email import Feed, isstr

for tmp in os.listdir(location + "/" + DATA_PATH):
	rss2email.feedfile = location + "/" + DATA_PATH + '/' + tmp
	rss2email.run()
