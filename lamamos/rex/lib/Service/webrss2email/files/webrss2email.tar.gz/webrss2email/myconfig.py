RSS2EMAIL_PATH = "rss2email"
DATA_PATH = "data"

