#!/usr/bin/python
# -*- coding: utf-8 -*-
print "Content-Type: text/html"  
print

###############################################################################
# Load lib
###############################################################################
from myconfig import *
import sys
sys.path.append(RSS2EMAIL_PATH)
import cgi
import os
import rss2email
from rss2email import Feed, isstr
import cPickle as pickle
import gettext

def iif(condition,truePart,falsePart):
	if condition :
		result = truePart
	else :
		result = falsePart
	return result

application = "webrss2email"
form = cgi.FieldStorage()
###############################################################################
# Exit If not http Auth
###############################################################################
if not os.environ.has_key('REMOTE_USER'):
	print "<html><head><title>" + application + "</title></head><body>"
	print _("Error : Unkown User") + "</body></htm>l"
	exit(0)

###############################################################################
# Retrieves the user name and create the archive if necessary and load data
###############################################################################
#split("/") for openid auth
user = os.environ['REMOTE_USER'].split("/")[-1:][0]
if not user + ".dat" in os.listdir(DATA_PATH):
	pickle.dump([], open(DATA_PATH + "/" + user + ".dat", 'w'))
rss2email.feedfile = DATA_PATH + "/" + user + ".dat"
feeds, feedfileObject = rss2email.load(0)

###############################################################################
# Select language of browser if possible
###############################################################################
lang = os.environ['HTTP_ACCEPT_LANGUAGE'].split(',')[0]
gettext.install(application, "lang", unicode=True)
if lang in os.listdir('lang'):
	gettext.translation(application, "lang", languages=[lang]).install()


###############################################################################
# 
###############################################################################
if "action" in form :
	if form["action"].value in ["delete",'pause','unpause','run']:
		items=[]
		for tmp in form.keys():
			if tmp[0:4] == "feed":
				items.append(int(form[tmp].value))
		items.sort()
		items.reverse()	
		for tmp in items:
			if form["action"].value == "delete" :
				rss2email.delete(tmp) 
			elif form["action"].value == "pause" :
				rss2email.toggleactive(tmp,False)
			elif form["action"].value == "unpause" :
				rss2email.toggleactive(tmp,True)
			elif form["action"].value == "run" :
				rss2email.run(tmp)
	elif form["action"].value == "add" and "url" in form and "email" in form:
		if form["email"].value == feeds[0] :
			rss2email.add(form['url'].value)
		else : 
			rss2email.add(form['url'].value,form["email"].value)
	elif form["action"].value == "email" and "email" in form :
		rss2email.email(form['email'].value)
	elif form["action"].value == "runall" :
		rss2email.run()

###############################################################################
# Redirect page after action 
###############################################################################
	tmp = "list"
	if "show" in form:
		tmp = form["show"].value
	print 	"""
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
		<html>
		 <head>
		  <title>""" + application + """</title>
		  <meta http-equiv="REFRESH" content="0;url=?show=""" + tmp + """">
		 </head>
		 <body></body>
		</HTML>
		"""
	exit(0)

###############################################################################
# Begin template of the HTML page
###############################################################################
print 	""" 
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
	 <head>
	  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	  <meta http-equiv="Content-Language" content="fr" />
	  <title>Web rss2email</title>
	  <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" />
	  <style type="text/css" media="screen">@import url(css/global.css);</style>
	  <!--[if IE]><style type="text/css" media="screen">@import url(css/ie.css);</style><![endif]-->
	  <!--[if lte IE 6]><style type="text/css" media="screen">@import url(css/ie6.css);</style><![endif]-->
	  <script language="javascript">
	   function setCookie(sName, sValue) {
	    var today = new Date(), expires = new Date();
	    expires.setTime(today.getTime() + sValue );
	    document.cookie = sName + "=" + encodeURIComponent(sValue) + ";expires=" + expires.toGMTString();
	   }
	  </script>
	 </head>
         <body id="global">
         <div id="en-tete">
	  <p style='display:block;text-align:center;font-size: 1.7em'>Web rss2email</p>
          <ul>
	"""

###############################################################################
# Managing Tabs
###############################################################################
print "<li " + iif(not "show" in form or form["show"].value == 'list',"id='actif'>","><a href='?show=list'>") 
print "<span>" + _("Manage feeds") + "</span>"
print iif(not "show" in form or form["show"].value == 'list',"","</a>") + "</li>"

print "<li " + iif("show" in form and form["show"].value == 'add',"id='actif'>","><a href='?show=add'>") 
print "<span>" + _("Add feed") + "</span>"
print iif("show" in form and form["show"].value == 'add',"","</a>") + "</li>"

print "<li " + iif("show" in form and form["show"].value == 'email',"id='actif'>","><a href='?show=email'>") 
print "<span>" + _("Default email") + "</span>"
print iif("show" in form and form["show"].value == 'email',"","</a>") + "</li>"

#Logout for Apache Auth openId module
if 'HTTP_COOKIE' in os.environ.keys():
	print "<li><a href='?' onclick='setCookie(\"" + os.environ['HTTP_COOKIE'].split("=")[0] + "\",-1000);'>"
	print "<span>" + _("Logout") + "</span></a>"
	print "</li>"

print 	"""
	  </ul>
	 </div>
	 <br/>
	"""

###############################################################################
#  Manage feeds tab
###############################################################################
if not "show" in form or form["show"].value == 'list':
   if len(feeds) > 1 : 
	cpt = 0
	print "<form>"
	print "<table width='100%' align='center' border='1'>"
	print "<tr>"
	print "<td align='center' style='font-weight : 700;' >" + _("Num")+"</td>"
	print "<td align='center' style='font-weight : 700;' >" + _("Feed url") + "</td>"
	print "<td align='center' style='font-weight : 700;' >" + _("Status") + "</td>"
	print "<td align='center' style='font-weight : 700;' >" + _("Email") + "</td>"
	print "<td align='center' style='font-weight : 700;' >" + _("Select") + "</td>"
	print "</tr>"
	for tmp in feeds[1:]:
		cpt = cpt + 1
		print "<tr>"
		print "<td align='center'>" + str(cpt) + "</td>"
		print "<td><a style='color:#000000' target=_blank href='" + tmp.url + "'>" + tmp.url+ "</a></td>"
		print "<td align='center' style='color:" + iif(tmp.active  ,"#0000FF","#FF0000") , "'>" 
		print iif(tmp.active  , _("Active")  , _("Pause")) + "</td>"
		print "<td align='center'>" + iif(tmp.to==None,_("Default"),tmp.to ) + "</td>"
		print "<td align='center'><input type='checkbox' name='feed" + str(cpt)+"' value='" + str(cpt) + "'></td>"
		print "</tr>"
	print "</table>"
	print "<br/>"
	print "<select name='action'>"
	print "<option value='delete'>" + _("Delete") + "</option>"
	print "<option value='pause'>" + _("Pause") + "</option>"
	print "<option value='unpause'>" + _("Activate") + "</option>"
	print "<option value='run'>" + _("Send by email") + "</option>"
	print "</select'>"
	print "<input type='submit' value='" + _("Ok") + "'>"
	print "</form>"
   else : 
	print "<center>" + _("There is no feed") + "</center>"
###############################################################################
# Add feed tab
###############################################################################
elif form["show"].value == 'add':
   if len(feeds) > 0 :
	print "<form>"
	print "<center>"
	print "<input type='hidden' name='action' value='add'>"
	print "<input type='hidden' name='show' value='list'>"
	print "<table>"
	print "<tr>"
	print "<td>" + _("Feed url") + " : </td>"
	print "<td><input type='text' name='url' value='http://' size='35'></td>"
	print "<tr>"
	print "</tr>"
	print "<td>" + _("Email") + " : </td>"
	print "<td><input type='text' name='email' value='"+ feeds[0] + "' size='35'></td>"
	print "</tr>"
	print "</table>"
	print "<input type='submit' value='" + _("Add") + "'>"
	print "</center>"
	print "</form>"
   else:
	print "<center>" 
	print _("It is necessary to set the default mail receipt to add a feed") 
	print "</center>"
###############################################################################
# Default email tab
###############################################################################
elif form["show"].value == 'email':
	print "<form>"
	print "<center>"
	print "<input type='hidden' name='action' value='email'>"
	print "<input type='hidden' name='show' value='email'>"
	print _("Email") + " : "
	if len(feeds) == 0 :
		print "<input type='text' name='email' value='' size='30'>"
		print "<input type='submit' value='" + _("Ok") + "'>"
	else :
		print "<input type='text' name='email' value='"+feeds[0]+"' size='30'>"
		print "<input type='submit' value='" + _("Change") + "'>"
	print "</center>"
	print "</form>"
	
###############################################################################
# end template of the HTML page
###############################################################################
print "</body>"
print "</html>"

#import crypt
#print("%s:%s" % (sys.argv[1], crypt.crypt(sys.argv[2], sys.argv[2])))
